#include <stdio.h>
#include <stdlib.h>

void fun(char *n,int m,int tab[][m])
{
    tab[0][0]=5;
}
int main()
{
    char n[]="ABCDE";
    int m=2;
    int tab[2][2]={{1,2},{3,4}};
    fun(n, m, tab);
    printf("%d\n",tab[0][0]);
    return 0;
}
