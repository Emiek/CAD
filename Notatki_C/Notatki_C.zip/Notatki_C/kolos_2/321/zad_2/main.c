#include <stdio.h>
#include <stdlib.h>

int dlugosc_napisu(char *napis1)
{
    int pom1=0,pom2=0;
    while(napis1[pom2]!=0)
    {
        if(napis1[pom2]>=48 && napis1[pom2]<=57)
            pom1++;
        pom1++;

        pom2++;
    }
    return pom1;
}

int main()
{
    char napis1[]="AB123";
    printf("%d\n",dlugosc_napisu(napis1));
    return 0;
}
