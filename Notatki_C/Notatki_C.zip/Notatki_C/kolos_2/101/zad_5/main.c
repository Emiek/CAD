#include <stdio.h>
#include <stdlib.h>
struct element {
    float i;
    struct element * next;
};

int rozmiar(struct element* lista)
{
    struct element * wsk1;
    wsk1=lista;
    int pom1=0;
    while(wsk1!=NULL)
    {
        pom1+=1;
        wsk1=wsk1->next;
    }
    return pom1;
}


void foo(struct element * lista)
{
    struct element * wsk,*wsk2,*wsk3;
    for(int i=0;i<=rozmiar(lista);i++)
    {
        wsk=lista->next;
        wsk2=NULL;
        while(wsk!=NULL)
        {
            if(wsk->i <0)
            {
                wsk2=wsk;
            }
            wsk=wsk->next;
        }
        if (wsk2!=NULL)
        {
            wsk3=lista;
            while(wsk3->next != wsk2)
            {
                wsk3=wsk3->next;
            }
            wsk3->next= wsk2->next;
            free(wsk2);
        }
    }
}


void wyswietl(struct element* lista)
{
    struct element * current=lista;
    while(current!=NULL)
    {
        printf("%f\n", current->i);
        current= current->next;
    }
    printf("---\n");
}


int main()
{
    struct element* lista1 = malloc(sizeof(struct element));
    lista1->i=7;

    lista1->next=malloc(sizeof(struct element));
    lista1->next->i=-8;

    lista1->next->next=malloc(sizeof(struct element));
    lista1->next->next->i=12;

    lista1->next->next->next=malloc(sizeof(struct element));
    lista1->next->next->next->i=-16;

    lista1->next->next->next->next=NULL;

    printf("rozmiar listy=%d\n",rozmiar(lista1));
    wyswietl(lista1);
    foo(lista1);
    wyswietl(lista1);
    return 0;
}
