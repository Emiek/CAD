/*
2.Napisz funkcj�, kt�ra dostaje w argumencie dwa napisy i liczb� ca�kowit� n.
Funkcja ma zwr�ci� 1 je�li znak o indeksie n w pierwszym napisie jest wcze�niej
w tablicy ASCII ni� znak o indeksie n w drugim napisie. W przeciwnym wypadku
albo gdy kt�ry� z napis�w jest kr�tszy, to funkcja ma zwr�ci� 0. W zadaniu nie
korzystaj z funkcji bibliotecznych. Stw�rz przypadek testowy.
*/
#include <stdio.h>
#include <stdlib.h>

int foo(char *napis1, char *napis2, int n)
{
    if(napis1[n]<napis2[n])
        return 1;
    return 0;
}

int main()
{
    int n = 6;
    char napis1[10] = "BBB";
    char napis2[10] = "AAAAAA";
    printf("%d\n",foo(napis1, napis2, n));

    return 0;
}
