
/*
Napisz funkcj�, kt�rej argumentem jest dwuwymiarowa tablica tablic i jej wymiary n i m.
Funkcja ma zwr�ci� sum� sze�cian�w element�w znajduj�cych si� na g��wnej przek�tnej tablicy.
W zadaniu nie korzystaj ze wbudowanych funkcji matematycznych. Stw�rz przypadek testowy.

Przyk�ad: dla poni�szej tablicy ma wyj��: 2^3+8^3+(-2)^3=...
2	3	-2	8
-1	8	-4	3
3	5	-2	-9
*/

#include <stdio.h>
#include <stdlib.h>

int foo(int **tab, int n, int m)
{
    int pom1=n;
    int pom2=0;
    if(n>m)
        pom1=m;

    for(int i=0;i<pom1;i++)
    {
        pom2 = pom2+((tab[i][i]) * (tab[i][i]) * (tab[i][i]));
    }
    return pom2;
}
int main()
{
    int n, m;
    n=2;
    m=3;
    int **tab=malloc(n*sizeof(int*));
    tab[0]=malloc(m*sizeof(int*));
    tab[1]=malloc(m*sizeof(int*));
    tab[0][0]=1;
    tab[0][1]=2;
    tab[0][2]=3;
    tab[1][0]=4;
    tab[1][1]=5;
    tab[1][2]=6;



    printf("%d\n",foo(tab, n, m));
    return 0;
}
