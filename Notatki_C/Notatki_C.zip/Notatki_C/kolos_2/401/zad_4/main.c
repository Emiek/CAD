#include <stdio.h>
#include <stdlib.h>

struct Student
{
    char * imie;
    int numer_indeksu;
};

int fun(struct Student tab[], int n)
{
    int min=tab[0].numer_indeksu;
    for(int i=1;i<n;i++)
    {
        if(tab[i].numer_indeksu<min)
            min=tab[i].numer_indeksu;
    }
    return min;
};

int main()
{
    int n=4;
    struct Student student1 = {"kasia",464545};
    struct Student student2 = {"szymon",164833};
    struct Student student3 = {"patryk",843234};
    struct Student student4 = {"rafal",165123};
    struct Student tab[4] = {student1, student2, student3, student4};
    printf("%d \n",fun(tab, n));
    return 0;
}
