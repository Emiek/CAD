#include <stdio.h>
#include <stdlib.h>

int fun(int **tab, int n, int m)
{
    int suma_kwadratow=0;
    int pom1=n;
    if(n>m)
        pom1=m;

    for(int i=0;i<pom1;i++)
    {
        suma_kwadratow=suma_kwadratow+(tab[i][i]*tab[i][i]);
    }
    return suma_kwadratow;
}

void wyswietl(int **tab, int n, int m)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            printf("%d ",tab[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main()
{
    int n=3,m=4;
    int ** tab = malloc(3 * sizeof(int*));
    tab[0] = malloc(4 * sizeof(int));
    tab[1] = malloc(4 * sizeof(int));
    tab[2] = malloc(4 * sizeof(int));
    tab[0][0] = 2;
    tab[0][1] = 3;
    tab[0][2] = -2;
    tab[0][3] = 8;
    tab[1][0] = -1;
    tab[1][1] = 8;
    tab[1][2] = -4;
    tab[1][3] = 3;
    tab[2][0] = 3;
    tab[2][1] = 5;
    tab[2][2] = -2;
    tab[2][3] = -9;

    wyswietl(tab, n, m);
    printf("%d\n",fun(tab, n, m));

    return 0;
}
