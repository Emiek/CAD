#include <stdio.h>
#include <stdlib.h>

struct test
{
    int a;
    char b;
};

int main()
{
    struct test zm = {501,'y'};
    int*p;
    p=&zm; // p=  , *p=
    char w = zm.b; // w=  , &w=
    p++; // p=  , *p=
    w--; // w=  , &w=
    zm.b=99;  // w=  , &w=
    return 0;
}
