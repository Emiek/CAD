#include <stdio.h>
#include <stdlib.h>

int foo(char *napis1)
{
    int pom=0, pom2=0;
    while(napis1[pom]!=0)
    {
        if(napis1[pom]>=48 && napis1[pom]<=57)
            pom2=pom2-2;
        pom2++;
        pom++;
    }
    return pom2;
}

int main()
{
    char napis1[]="ABCabc123";
    printf("%d\n",foo(napis1));
    return 0;
}
