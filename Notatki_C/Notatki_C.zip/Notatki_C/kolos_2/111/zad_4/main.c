#include <stdio.h>
#include <stdlib.h>

struct Samolot
{
    char * model;
    int liczba_silnikow;
};

int fun(struct Samolot tab[], int n)
{
   int pom=tab[0].liczba_silnikow;
   for(int i=1;i<n;i++)
   {
       if(tab[i].liczba_silnikow<pom)
       {
           pom = tab[i].liczba_silnikow;
       }
   }
   return pom;

}

int main()
{
    int n=3;
    struct Samolot zm1 = {"sam1", 2};
    struct Samolot zm2 = {"sam2", 1};
    struct Samolot zm3 = {"sam3", 3};
    struct Samolot tab[3] = {zm1, zm2, zm3};
    printf("%d\n",fun(tab, n));
    return 0;
}
