#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void usun(char *napis)
{
    for(int i=0;i<=strlen(napis)/2;i++)
    {
        napis[i]=napis[i*2];
    }
    napis[strlen(napis)/2]='\0';
}
int main()
{
    char napis1[10];
    napis1[0]='A';
    napis1[1]='1';
    napis1[2]='B';
    napis1[3]='2';
    napis1[4]='C';
    napis1[5]='3';
    napis1[6]='D';
    napis1[7]='4';
    napis1[8]='E';
    napis1[9]='\0';

    char napis2[]="A1B2C3D4E";

    //usun(napis1);
    //printf( "%s", napis1);
    usun(napis2);
    printf( "%s", napis2);

}
