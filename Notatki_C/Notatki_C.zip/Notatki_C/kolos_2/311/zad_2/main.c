#include <stdio.h>
#include <stdlib.h>

int dlugosc_napisu(char *napis1)
{
    int pom=0;
    while(napis1[pom]!=0)
    {
        pom++;
    }
    return pom;
}

int fun(char *napis1, char *napis2, int n)
{
    if(napis1[n]>napis2[n] || dlugosc_napisu(napis1)!=dlugosc_napisu(napis2))
        return 0;
    else
        return 1;
}
int main()
{
    int n=3;
    char napis1[]="ABC";
    char napis2[]="abcD";
    printf("%d\n",fun(napis1, napis2, n));
    return 0;
}
