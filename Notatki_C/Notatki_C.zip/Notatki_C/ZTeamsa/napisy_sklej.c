#include <stdio.h>
#include <stdlib.h>

void sklej(char napis1[],char napis2[],char napis3[])
{
    int i,j;
    for(i=0;napis1[i] != 0;i++)
    {
        napis3[i]=napis1[i];
    }
    for(j=0;napis2[j] != 0;j++)
    {
        napis3[j+i]=napis2[j];
    }
    napis3[i+j]=0;
}
int main()
{
    char n1[]="abc\n";
    char n2[]=" XYZ";
    char n3[10];
    sklej(n1,n2,n3);
    printf("%s\n",n1);
    printf("%s\n",n2);
    printf("%s\n",n3);
    return 0;
}
