#include <stdio.h>
#include <stdlib.h>

struct trojkat
{
    int a,b,c;
};

int obwod(struct trojkat arg)
{
    return arg.a+arg.b+arg.c;
}

int main()
{
    struct trojkat t1 = {3,5,4};
    printf("%d\n",obwod(t1));
    struct trojkat t2 = {.a=3,.c=5,.b=4};
    printf("%d\n",obwod(t2));
    return 0;
}
