#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int foo(char* napis)
{
    int temp=0;
    for(int i=0;napis[i] !=0;i++)
    {
        if (isdigit(napis[i]) != 0)
        {
            temp++;
        }
    }
    return temp;
}
int foo2(char* napis)
{
    int temp=0;
    for(int i=0;napis[i] !=0;i++)
    {
        if (48<= napis[i] && napis[i]<=57)
        {
            temp++;
        }
    }
    return temp;
}
int main()
{
    char n1[]="abc123XYZ";
    printf("%d\n", foo(n1));
    printf("%d\n", foo2(n1));
    return 0;
}
