#include <stdio.h>
#include <stdlib.h>

struct Samolot
{
    char * model;
    int liczba_silnikow;
};

char * fun(struct Samolot tab[], int n)
{
    int maks = 0;
    char * samolot = tab[0].model;
    for(int i =0;i<n;i++)
    {
        if (tab[i].liczba_silnikow > maks)
        {
            maks = tab[i].liczba_silnikow;
            samolot = tab[i].model;
        }
    }
    return samolot;
}

int main()
{
    struct Samolot z1 = {"asd",2};
    struct Samolot z2 = {"asdxxx",6};
    struct Samolot z3 = {"asasdd",1};
    struct Samolot tab[3] = {z1,z2,z3};
    printf("%s\n",fun(tab,3));
    return 0;
}
