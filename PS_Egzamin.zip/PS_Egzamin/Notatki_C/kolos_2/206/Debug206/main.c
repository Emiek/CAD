#include <stdio.h>
#include <stdlib.h>

int main()
{
    char wyraz[]="iiiiiiaaaaaaaaaabbbbbbbbbb";
    char * w= wyraz;  // w=   , * w=
    int q = sizeof(char); // q=
    w = wyraz+3; // w=   , * w=
    char t = *wyraz+22; //t=    , &t=
    t = *(wyraz+2)+15;   //t=    , &t=
    w =&(*(wyraz+4))+9; // w=   , * w=
    *w=(wyraz+5)[-3]; // w=    , *w=
    return 0;
}
