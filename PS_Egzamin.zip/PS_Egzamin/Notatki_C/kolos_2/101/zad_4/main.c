#include <stdio.h>
#include <stdlib.h>
/*
wchar_t [ ] ( ) void int int fun n m tab m [ ] , , *
U��z je we w�asciwej kolejnosci, aby otrzymac nag��wek funkcji fun, kt�ra dostaje jako argumenty napis,
liczbe ca�kowita oraz dwuwymiarowa
*/

void fun(wchar_t *n, int m,int tab[ ][m])
{

}

int main()
{

}
