#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void foo(char *napis)
{
    for(int i=0;i<strlen(napis)/2;i++)
    {
        napis[i] = napis[i*2];
    }
    napis[strlen(napis)/2] ='\0';
}
int main()
{
    char napis[] = "A1B2C3D4E5F6";
    printf("%s\n",napis);
    foo(napis);
    printf("%s\n",napis);
    return 0;
}
