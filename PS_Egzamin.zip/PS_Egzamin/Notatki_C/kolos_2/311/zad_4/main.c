#include <stdio.h>
#include <stdlib.h>


double fun(char *n,int m, int tab[][m])
{
    return 1.2;
}
int main()
{
    char n[]="ABCDE";
    int m=2;
    int tab[2][2]={{1,2},{3,4}};

    printf("%lf\n",fun(n, m, tab));
    return 0;
}
