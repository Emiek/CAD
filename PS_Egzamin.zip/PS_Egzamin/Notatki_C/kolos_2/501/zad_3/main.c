#include <stdio.h>
#include <stdlib.h>

void fun(int n, int m, int tab[n][m])
{
    int tab2[n][m];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            tab2[i][j]=tab[i][j];
            printf("%d ",tab[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            tab[i][j]=tab2[i][m-1-j];
            printf("%d ",tab[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int n=3,m=4;
    int tab[3][4]={{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11 ,12}};
    fun(n, m, tab);
    return 0;
}
