#include <stdio.h>
#include <stdlib.h>

int main()
{
    char wyraz[]="@abcdefgh$$ijklmnoprst@";
    char * w= wyraz;  // w=   , * w=
    int q = sizeof(char); // q=
    char t = *wyraz+2; //t=    , &t=
    t = *(wyraz+2);   //t=    , &t=
    *w=(wyraz+7)[-3]; // w=    , *w=
    w =&(*(wyraz+3))-1; // w=   , * w=
    w = wyraz+7; // w=   , * w=
    return 0;
}
