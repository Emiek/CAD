#include <stdio.h>
#include <stdlib.h>

int foo(int a)
{
    return a+5;
}

int main()
{
    int tab[4][4] = {{1,1,1,-2},{7,1,1,1},{-8,4,1,2}, {-9,-8,-2,-3}};
    int a = sizeof(int*); //a=
    int * p = tab+1; //p= , *p =
    int r = *(*(tab+2)-1)+foo(3); // r= , &r=
    *p=foo(*p); //p= , **p =
    r= *(*(tab+1)+4); // r= , &r=
    return 0;
}
