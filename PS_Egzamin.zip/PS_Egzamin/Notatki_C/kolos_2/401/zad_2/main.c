#include <stdio.h>
#include <stdlib.h>

int dlugosc_napisu(char *napis1)
{
    int pom=0;
    while(napis1[pom]!=0)
    {
        pom++;
    }
    return pom;
}

void foo(char *napis1)
{
    for(int i=0;i<=dlugosc_napisu(napis1);i++)
    {
        if(napis1[i]>=97 && napis1[i]<=122)
            napis1[i] = 64;
    }
}
int main()
{
    char napis1[] = "abcABC123";
    printf("%s\n",napis1);
    foo(napis1);
    printf("%s\n",napis1);
    return 0;
}
