#include <stdio.h>
#include <stdlib.h>
//
//
//to jest zle
//
//
union Test
{
    int a;
    float b;
};

void fun(union Test tab[], int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d \n",tab[i]);
    }

};

int main()
{
    int n=6;

    union Test zm1;
    zm1.a = 1;
    union Test zm2;
    zm2.b = 2.2;
    union Test zm3;
    zm3.a = 3;
    union Test zm4;
    zm4.b = 4.4;
    union Test zm5;
    zm5.a = 5;
    union Test zm6;
    zm6.b = 6.6;
    union Test tab[6] = {zm1, zm2, zm3, zm4, zm5, zm6};

    fun(tab, n);

    return 0;
}
