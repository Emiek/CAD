#include <stdio.h>
#include <stdlib.h>

int dlugosc_napisu(char *napis1)
{
    int pom=0;
    while(napis1[pom]!=0)
    {
        pom++;
    }
    return pom;
}

char foo(char *napis1)
{
    for(int i=0;i<dlugosc_napisu(napis1);i++)
    {
        if(napis1[i]>=97 && napis1[i]<=122)
            return napis1[i];
    }
}

int main()
{
    char znak1[]="ABCabc123";
    printf("%c\n",foo(znak1));
    return 0;
}
