#include <stdio.h>
#include <stdlib.h>

int main()
{
    char wyraz[]="24836477364abc";
    char * w= wyraz;  // w=   , * w=
    int q = sizeof(char); // q=
    w = wyraz+5; // w=   , * w=
    char t = *wyraz+2; //t=    , &t=
    t = *(wyraz+2);   //t=    , &t=
    *w=(wyraz+7)[-3]; // w=    , *w=
    w =&(*(wyraz+3))-1; // w=   , * w=
    return 0;
}
