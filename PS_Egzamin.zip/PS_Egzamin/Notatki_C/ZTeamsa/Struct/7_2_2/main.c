#include <stdio.h>
#include <stdlib.h>

struct trojkat
{
    int a,b,c;
};

void foo(struct trojkat troj, struct trojkat *troj2)
{
    *troj2=troj;
}

int main()
{
    struct trojkat t1 = {3,5,4};
    struct trojkat t2 = {5,6,7};
    foo(t1,&t2);
    printf("%d %d %d\n",t1.a,t1.b,t1.c);
    printf("%d %d %d\n",t2.a,t2.b,t2.c);
    return 0;
}
