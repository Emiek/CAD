#include <stdio.h>
#include <stdlib.h>

enum zwierzak { PIES=9, KOT, KURA=9, CHOMIK};

int main()
{
    enum zwierzak z1 = CHOMIK;
    printf("%d\n",z1);
    printf("%Iu", sizeof(enum zwierzak));
    return 0;
}
