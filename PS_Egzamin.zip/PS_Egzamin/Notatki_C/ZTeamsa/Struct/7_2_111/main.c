#include <stdio.h>
#include <stdlib.h>

union Liczba
{
    int a;
    float b;
};

struct Dane
{
    int tp;
    union Liczba zaw;
};

struct Dane wczytaj()
{
    struct Dane temp;
    printf("Podaj 0 jesli calk lub 1 jesli wym\n");
    scanf("%d", &temp.tp);
    if(temp.tp ==0 )
    {
        printf("Podaj liczbe calk\n");
        scanf("%d",&temp.zaw.a);
    }
    else
    {
        printf("Podaj liczbe wym\n");
        scanf("%f",&temp.zaw.b);
    }
    return temp;
};

void wyswietl(struct Dane arg)
{
    if(arg.tp ==0)
    {
        printf("%d\n",arg.zaw.a);
    }
    else
    {
        printf("%f\n",arg.zaw.b);
    }
}

int main()
{
    union Liczba zm;
    zm.a=9;
    printf("%d\n",zm.a);
    printf("%f\n",zm.b);
    zm.b=1.2;
    printf("%d\n",zm.a);
    printf("%f\n",zm.b);
    struct Dane d1 = wczytaj();
    wyswietl(d1);
    return 0;
}
