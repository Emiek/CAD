#include <stdio.h>
#include <stdlib.h>

int * foo()
{
    int * temp = malloc(4*sizeof(int));
    *temp =5;
    *(temp+1)=2;
    *(temp+2)=-3;
    *(temp+3)=-5;
    return temp;
}

int main()
{
    int* wsk= foo();
    printf("%d\n",*wsk);
    printf("%d\n",*(wsk+1));
    printf("%d\n",*(wsk+2));
    printf("%d\n",*(wsk+3));
    return 0;
}
