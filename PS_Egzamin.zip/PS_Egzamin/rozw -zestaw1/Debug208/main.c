#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tab[4][4] = {{1,2,2,0},{7,8,4,3},{-8,4,1,2}, {208,-3,5,-2}};
    int a = sizeof(int*); //a=8
    int * p = tab+2; //p=0x22fe10 , *p =-8
    int r = *(*(tab+2)-1); // r=3 , &r=0x22fe3c
    r= *(*(tab+2)+1); // r=4 , &r=0x22fe3c
    *p=*(tab+1)+7; //p=0x22fe10 , **p =2
    return 0;
}
