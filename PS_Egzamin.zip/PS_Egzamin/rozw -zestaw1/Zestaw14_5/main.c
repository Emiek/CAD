#include <stdio.h>
#include <stdlib.h>

struct element {
    float i;
    struct element * next;
};

void foo(struct element * lista)
{
    struct element * wsk,*wsk2,*wsk3;
    wsk=lista->next;
    wsk2=NULL;
    while(wsk!=NULL)
    {
        if(wsk->i >0)
        {
            wsk2=wsk;
        }
        wsk=wsk->next;
    }
    if (wsk2!=NULL)
    {
        wsk3=lista;
        while(wsk3->next != wsk2)
        {
            wsk3=wsk3->next;
        }
        wsk3->next= wsk2->next;
        free(wsk2);
    }
}
void wyswietl(struct element* lista)
{
    struct element * current=lista->next;
    while(current!=NULL)
    {
        printf("%f\n", current->i);
        current= current->next;
    }
    printf("---\n");
}

int main()
{
    struct element* lista1 = malloc(sizeof(struct element));
    lista1->next=malloc(sizeof(struct element));
    lista1->next->i=7;
    lista1->next->next=malloc(sizeof(struct element));
    lista1->next->next->i=8;
    lista1->next->next->next=malloc(sizeof(struct element));
    lista1->next->next->next->i=12;
    lista1->next->next->next->next=NULL;
    wyswietl(lista1);
    foo(lista1);
    wyswietl(lista1);
    return 0;
}
