#include <stdio.h>
#include <stdlib.h>

char * foo(char* napis, char* napis2)
{
    return "ABC";
}

int main()
{
    printf("%s\n",foo("xyz","pk"));
    return 0;
}
