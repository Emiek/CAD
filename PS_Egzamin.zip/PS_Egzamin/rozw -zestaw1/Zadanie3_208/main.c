#include <stdio.h>
#include <stdlib.h>

void foo(int ** tab,int n, int m)
{
    if (n!=m)
        return;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<i;j++)
        {
            int temp=tab[j][i];
            tab[j][i]=tab[i][j];
            tab[i][j]=temp;
        }
    }
}

void wyswietl(int ** tab, int n, int m)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            printf("[%d,%d]=%d, ", i,j,tab[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int ** tab= malloc(3*sizeof(int*));
    tab[0]= malloc(3*sizeof(int));
    tab[1]= malloc(3*sizeof(int));
    tab[2]= malloc(3*sizeof(int));
    tab[0][0]=4;
    tab[0][1]=7;
    tab[0][2]=-2;
    tab[1][0]=11;
    tab[1][1]=88;
    tab[1][2]=29;
    tab[2][0]=-6;
    tab[2][1]=77;
    tab[2][2]=12;
    wyswietl(tab,3,3);
    foo(tab,3,3);
    wyswietl(tab,3,3);
    return 0;
}
