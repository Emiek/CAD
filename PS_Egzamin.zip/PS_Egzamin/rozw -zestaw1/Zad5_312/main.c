#include <stdio.h>
#include <stdlib.h>

struct element {
    float x;
    struct element * next;
};

void foo(struct element * lista)
{
    if (lista==NULL)
        return;
    struct element * current=lista;
    struct element * prev= lista;
    while(current->next!=NULL)
    {
        current=current->next;
        if( prev->x < 0)
        {
            current->x *= 3;
        }
        prev=current;
    }
}

void wyswietl(struct element* lista)
{
    struct element * current=lista;
    while(current!=NULL)
    {
        printf("%f\n", current->x);
        current= current->next;
    }
    printf("---\n");
}

int main()
{
    struct element* lista1 = malloc(sizeof(struct element));
    lista1->x=-2;
    lista1->next=malloc(sizeof(struct element));
    lista1->next->x=-7;
    lista1->next->next=malloc(sizeof(struct element));
    lista1->next->next->x=-8;
    lista1->next->next->next=malloc(sizeof(struct element));
    lista1->next->next->next->x=-12;
    lista1->next->next->next->next=NULL;
    wyswietl(lista1);
    foo(lista1);
    wyswietl(lista1);
    return 0;
}
