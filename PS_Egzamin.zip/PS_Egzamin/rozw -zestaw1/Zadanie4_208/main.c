#include <stdio.h>
#include <stdlib.h>

struct Zakupy
{
    char* napis;
    int ilosc;
    float cena;
};

float sumazakupow(struct Zakupy tab[],int n)
{
    float suma=0;
    for(int i=0;i<n;i++)
    {
        suma+= tab[i].ilosc * tab[i].cena;
    }
    return suma;
}

int main()
{
    struct Zakupy z1 = {"OLEJ",1,10.04};
    struct Zakupy z2 = {"JABLKA",4,6.25};
    struct Zakupy z3 = {"Gruszka",2,8.67};
    struct Zakupy tab[3] = {z1,z2,z3};
    printf("%f\n",sumazakupow(tab,3));
    return 0;
}
