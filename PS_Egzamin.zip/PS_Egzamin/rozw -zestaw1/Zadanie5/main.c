#include <stdio.h>
#include <stdlib.h>

struct element {
    int x;
    struct element * next;
};

int maks(struct element*lista)
{
    int temp=lista->x;
    while(lista->next != NULL)
    {
        lista=lista->next;
        if(temp < lista->x)
        {
            temp=lista->x;
        }
    }
    return temp;
}

int foo(struct element* lista1, struct element * lista2)
{
    if(lista1==NULL)
        return 0;
    if(lista2==NULL)
        return 0;
    if (maks(lista1) == maks(lista2))
    {
        return 1;
    }
    return 0;
}

int main()
{
    struct element* lista1 = malloc(sizeof(struct element));
    lista1->x=2;
    lista1->next=malloc(sizeof(struct element));
    lista1->next->x=-7;
    lista1->next->next=malloc(sizeof(struct element));
    lista1->next->next->x=8;
    lista1->next->next->next=NULL;
    printf("%d\n",maks(lista1));
    struct element* lista2 = malloc(sizeof(struct element));
    lista2->x=8;
    lista2->next=malloc(sizeof(struct element));
    lista2->next->x=-2;
    lista2->next->next=malloc(sizeof(struct element));
    lista2->next->next->x=-8;
    lista2->next->next->next=NULL;
    printf("%d\n",maks(lista2));
    printf("%d\n",foo(lista1,lista2));
    return 0;
}
