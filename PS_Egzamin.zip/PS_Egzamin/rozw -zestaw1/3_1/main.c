#include <stdio.h>
#include <stdlib.h>

int foo(int ** tab, int n, int m)
{
    int mini=tab[0][0];
    int maxi=tab[0][0];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(mini > tab[i][j])
            {
                mini=tab[i][j];
            }
            if(maxi < tab[i][j])
            {
                maxi=tab[i][j];
            }
        }
    }
    return maxi-mini;
}

int foo2(int ** tab, int n, int m)
{
    int mini=tab[0][0];
    int maxi=tab[0][0];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(mini > *(*(tab+i)+j) )
            {
                mini= *(*(tab+i)+j);
            }
            if(maxi < *(*(tab+i)+j))
            {
                maxi= *(*(tab+i)+j);
            }
        }
    }
    return maxi-mini;
}

int main()
{
    int ** tab=malloc(2*sizeof(int*));
    *tab=malloc(3*sizeof(int));
    *(tab+1)=malloc(3*sizeof(int));
    tab[0][0]=6;
    tab[0][1]=-4;
    tab[0][2]=4;
    tab[1][0]=11;
    tab[1][1]=-8;
    tab[1][2]=9;
    printf("%d\n",foo(tab,2,3));
    printf("%d\n",foo2(tab,2,3));
    return 0;
}
