#include <stdio.h>
#include <stdlib.h>


unsigned int suma(unsigned int n){
    unsigned int tab[n];
    unsigned int suma=0;
    for(int i=0; i<n+1; i++){
        tab[i] = i;
    }
    for (int i=1; i<n+1; i++){
        suma += tab[i]*tab[i]*tab[i];
    }
    return suma;
}

int main()
{
    unsigned int n=5;
    printf("%u", suma(n));
    return 0;
}
