#include <stdio.h>
#include <stdlib.h>

int fun(unsigned int n){
    int suma = 0;
    for (int i = n-1; i>0; i--)
    {
        if(i%5==0 || i%7==0)
            suma+=i;
    }
    return suma;
}

int main()
{
    unsigned int n = 10;
    printf("%d", fun(n));
    return 0;
}

