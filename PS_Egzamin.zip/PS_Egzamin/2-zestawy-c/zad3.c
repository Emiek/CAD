#include <stdio.h>
#include <stdlib.h>

int fun(int **tab,unsigned int n,unsigned int m){
    int mini=tab[0][0];
    int maxi=tab[0][0];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(mini > tab[i][j])
            {
                mini=tab[i][j];
            }
            if(maxi < tab[i][j])
            {
                maxi=tab[i][j];
            }
        }
    }
    return maxi-mini;
}

int main()
{
    int ** tab=malloc(2*sizeof(int*));
    *tab=malloc(3*sizeof(int));
    *(tab+1)=malloc(3*sizeof(int));
    tab[0][0]=1;
    tab[0][1]=2;
    tab[0][2]=3;
    tab[1][0]=4;
    tab[1][1]=5;
    tab[1][2]=6;
    printf("%d\n",fun(tab,2,3));
    return 0;
}
