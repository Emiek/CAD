#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Osoba{
    char imie[20];
    int wiek;
    float wzrost;
};


char * fun(struct Osoba tab[], int n){
    struct Osoba temp = tab[0];
    int maxwiek = tab[0].wiek;
    for (int i=1;i<n;i++){
        if(tab[i].wiek > maxwiek){
            maxwiek = tab[i].wiek;
            temp = tab[i];
            }
    }
    char * pom= malloc(20*sizeof(char));
    strcpy(pom,temp.imie);
    return pom;
}
int main()
{
    struct Osoba tab1 = {"Ala" , 20 , 150.12};
    struct Osoba tab2 = {"Jacek", 40, 192.35};
    struct Osoba tab3 = {"Pawel", 30, 174.55};
    struct Osoba tab[3] = {tab1,tab2,tab3};
    printf("%s", fun(tab,3));
    return 0;
}
