#include <stdio.h>
#include <stdlib.h>

char *foo(char *napis1, char *napis2){
    return napis1;
}

int main()
{
    char napis1[] = "ala";
    char napis2[] = "kot";
    printf("%s",foo(napis1,napis2));
    return 0;
}
