#include <stdio.h>
#include <stdlib.h>


struct node{
    float x;
    struct node *next;
};

int fun(struct node *lista){
    struct node *wsk = lista;
    if(lista == NULL)
        return 0;
    while(wsk!=NULL)
    {
        if(wsk->x<=0)
            {
                return 0;
            }
        wsk = wsk->next;
    }
    return 1;
}


int main()
{
    struct node * lista= malloc(sizeof(struct node));
    lista->x = 4.5;
    lista->next=malloc(sizeof(struct node));
    lista->next->x=-3.9;
    lista->next->next=malloc(sizeof(struct node));
    lista->next->next->x=9.2;
    lista->next->next->next=NULL;
    struct node * lista2= malloc(sizeof(struct node));
    lista2->x=11.2;
    lista2->next=NULL;
    printf("%d", fun(lista));
    return 0;
}
