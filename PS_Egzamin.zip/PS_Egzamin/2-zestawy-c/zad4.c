#include <stdio.h>
#include <stdlib.h>

struct element{
float x;
struct element *next;
};

void foo(struct element *lista){
    if (lista==NULL){
        printf("%p\n%p\n",NULL,NULL);
        return;
        }
    printf("%p", lista);
    struct element *wsk = lista;
    while(wsk->next!=NULL)
        wsk = wsk->next;
    printf("%p",wsk);
}

void wyswietl(struct element * lista)
{
    struct element * wsk = lista;
    while(wsk!=NULL)
    {
        printf("Adres:%p, wartosc: %f\n",wsk,wsk->x);
        wsk=wsk->next;
    }
    printf("---\n");
}

int main()
{
    struct element * lista= malloc(sizeof(struct element));
    lista->x = 4.5;
    lista->next=malloc(sizeof(struct element));
    lista->next->x=-3.9;
    lista->next->next=malloc(sizeof(struct element));
    lista->next->next->x=9.2;
    lista->next->next->next=NULL;
    foo(lista);
    struct element * lista2= malloc(sizeof(struct element));
    lista2->x=11.2;
    lista2->next=NULL;
    foo(lista);
    return 0;
}
