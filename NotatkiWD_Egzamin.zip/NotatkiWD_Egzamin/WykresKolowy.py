import pylab as plt
fig, ax1 = plt.subplots()
x = [37, 47, 49, 26, 23]
label = ["A", "B", "C", "D", "E"]
color = ["tab:green", "tab:brown", "tab:purple", "lightsteelblue", "mediumseagreen"]
ax1.pie(x, labels=x, colors=color, startangle=90)
plt.legend(label, loc='upper right', bbox_to_anchor=(0.87, 1.05))
ax1.axis('equal')
plt.title("Tytuł", pad=20.)
plt.tight_layout()
plt.savefig('wykres.jpg')
plt.show()
