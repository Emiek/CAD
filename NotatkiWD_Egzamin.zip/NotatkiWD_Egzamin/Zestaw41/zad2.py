import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

d = pd.read_excel("ceny41.xlsx")
df = pd.DataFrame(d)

a = df["Wartosc"][df["Rodzaje towarów i usług"] == "marchew - za 1 kg"]
da = pd.DataFrame(a)
x = np.arange(12)
da.set_index(x, inplace=True)
w = float(da.mean())
print("Marchew średnia cena :", w)
b = df["Wartosc"][df["Rodzaje towarów i usług"] == "cebula - za 1 kg"]
db = pd.DataFrame(b)
x2 = np.arange(12)
db.set_index(x2, inplace=True)
w2 = float(db.mean())
print("Cebula średnia cena :", w2)
c = df["Wartosc"][df["Rodzaje towarów i usług"] == "ziemniaki - za 1 kg"]
fig, ax = plt.subplots(figsize=(11, 9))
ax.plot(x, a, label="marchewka za 1kg")
ax.plot(x, b, label="cebula za 1kg")
ax.plot(x, c, label="ziemniaki za 1kg")
plt.legend()
plt.grid()
plt.xlabel("Miesiące")
plt.ylabel("zł")
plt.title("Wykres")
plt.xticks(x, labels=df["Miesiące"].unique(), rotation=45)
plt.text(-1.3, 0.7, "164333")
plt.savefig('wykres_zad2.jpg')
plt.show()




