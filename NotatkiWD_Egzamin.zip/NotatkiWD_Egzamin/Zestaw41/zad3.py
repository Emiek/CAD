import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

d = pd.read_csv('cechy41.csv', sep=';', header=0, decimal=',')
print(d.isna().sum())
d.dropna(axis=0, inplace=True)
print(d.isna().sum())
x = [i for i in np.arange(0, 201, 50)]

g = pd.DataFrame(data=d)
g['Cecha1_bin'] = pd.cut(g['Cecha1'], bins=x)
g['Cecha2_bin'] = pd.cut(g['Cecha2'], bins=x)
#g_binned=g.groupby(g['a_binned'])['a'].count()

g_bin = g.groupby(g['Cecha1_bin'])['Cecha1'].count()
g_bin2 = g.groupby(g['Cecha2_bin'])['Cecha2'].count()
d = g_bin
t = g_bin.cumsum().values
xx = ['od 0 do 50','od 50 do 100','od 100 do 150','od 150 do 200']
fig, ax = plt.subplots(ncols=2, figsize=(10, 5))
ax[0].barh(xx, g_bin)
ax[1].barh(xx, g_bin2)
plt.tight_layout()
plt.show()


