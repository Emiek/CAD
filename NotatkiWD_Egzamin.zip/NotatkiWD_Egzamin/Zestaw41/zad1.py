import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0.5, 10, 100)

y = np.log10(2*x)
y1 = -4*x + 2
y2 = 2*np.cos(x)

plt.plot(x, y, "-b", label="log(2x)")
plt.plot(x, y1, "-.g", label="-4x + 2")
plt.plot(x, y2, "--c", label="2cos(x)")
plt.title("wykresy")
plt.xlabel("x")
plt.ylabel("y")
plt.legend(loc="best")
plt.grid()
plt.savefig("wykresy_zad1.png")
plt.show()
